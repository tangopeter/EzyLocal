<?php exit(0);?>
{
	"serverType":  "apache",
	"min_php_version": "5.7",
	"min_mysql_version": "5.7",
	"min_mariadb_version": "10.3",
	"db_server": "DB_SERVERNAME",
	"db_name": "DB_NAME",
	"db_username": "DB_USERNAME",
	"db_password": "DB_PASSWORD"
}