<?php
/**
 * Theme functions and definitions
 *
 * @package HelloElementorChild
 */

/**
 * Load child theme css and optional scripts
 *
 * @return void
 */
function hello_elementor_child_enqueue_scripts() {
  wp_enqueue_style(
    'hello-elementor-child-style',
    get_stylesheet_directory_uri() . '/style.css',
    [
      'hello-elementor-theme-style',
    ],
    '1.0.0'
  );
}
add_action( 'wp_enqueue_scripts', 'hello_elementor_child_enqueue_scripts', 20 );




// Custom script with no dependencies, enqueued in the header 
// https://developer.wordpress.org/reference/functions/plugin_dir_url/
function my_scripts() {
  wp_enqueue_script('currency', get_stylesheet_directory_uri().'/scripts/currency.js', 
    array(), false, true);
}
add_action( 'wp_enqueue_scripts', 'my_scripts' );

// add_action('acf/input/admin_enqueue_scripts', 'my_acf_admin_enqueue_scripts');
// function my_acf_admin_enqueue_scripts() {
//     wp_enqueue_style( 'my-acf-input-css', get_stylesheet_directory_uri() . '/css/my-acf-input.css', false, '1.0.0' );
//     wp_enqueue_script( 'my-acf-input-js', get_stylesheet_directory_uri() . '/js/my-acf-input.js', false, '1.0.0' );
// }
  
function my_acf_user_form_func( $atts ) {

$a = shortcode_atts( array(
  'field_group' => ''
), $atts );

$uid = get_current_user_id();

if ( ! empty ( $a['field_group'] ) && ! empty ( $uid ) ) {
  $options = array(
  'post_id' => 'user_'.$uid,
  'field_groups' => array( intval( $a['field_group'] ) ),
  'return' => add_query_arg( 'updated', 'true', get_permalink() )
  );

  ob_start();

  acf_form( $options );
  $form = ob_get_contents();

  ob_end_clean();
  }

return $form;
}

add_shortcode( 'my_acf_user_form', 'my_acf_user_form_func' );

    
//adding AFC form head
function add_acf_form_head(){
  global $post;

  if ( !empty($post) && has_shortcode( $post->post_content, 'my_acf_user_form' ) ) {
  acf_form_head();
  }
}
add_action( 'wp_head', 'add_acf_form_head', 7 );




