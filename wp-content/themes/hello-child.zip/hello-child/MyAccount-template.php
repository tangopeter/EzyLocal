<?php
/**
 * The template for displaying singular post-types: posts, pages and user-defined custom post types.
 *
 * @package HelloElementor
* Template Name: My Account template
* Template Post Type: page
*/



$name = get_field('name');
$last_name = get_field('field_6357644e9f5b3');
$user_email = get_field('user_email');
$gst = get_field('field_6385714132de0');
$total_cost = get_field('field_6385716f32de1');
$testie = get_field('field_63866e3d26755');



get_header();
?>




<main id="content" <?php post_class( 'site-main' ); ?> role="main">
    <?php if ( apply_filters( 'hello_elementor_page_title', true ) ) : ?>
        <header class="page-header">
            <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
        </header>
    <?php endif; ?>
    <h3>dvTable</h3>
    <!-- https://www.aspsnippets.com/Articles/Insert-Header-Cell-TH-element-in-HTML-Table-using-JavaScript.aspx -->
    <div id="dvTable">
  
    <script type="text/javascript">

        // function GenerateTable() {
        console.log("line 39 = 404");
            //Build an array containing Customer records.
            var orders = new Array();
            orders.push(["Order #", "Date", "File", "Qty", "Size", "Finish", "Price", "Total"]);
            orders.push([2005, "12/12/2022", "018.jpg", 1,"10x8", "Gloss", 5.90, 5.90]);
     

            //Create a HTML Table element.
            var table = document.createElement("TABLE");
            // document.getElementById("dvTable").style.border = "thin solid #0000FF"; 
            // console.log("line 50");
            //Get the count of columns.
            var columnCount = orders[0].length;
            // console.log(columnCount);

            //Add the header row.
            var row = table.insertRow(-1);
            for (var i = 0; i < columnCount; i++) {
                var headerCell = document.createElement("TH");
                headerCell.innerHTML = orders[0][i];
                row.appendChild(headerCell);
            }
            console.log("line 61 = 426");
            // Add the data rows.
            for (var i = 1; i < orders.length; i++) {
                row = table.insertRow(-1);
                for (var j = 0; j < columnCount; j++) {
                    var cell = row.insertCell(-1);
                    cell.innerHTML = orders[i][j];
                }
            }
            console.log("line 70 = 435");
            var dvTable = document.getElementById("dvTable");
            dvTable.innerHTML = "";
            dvTable.appendChild(table);
            getWFUOrderTable();
        // }

function getWFUOrderTable(){
    console.log("line 79 = 443");
    // getWFUOrderTable = document.querySelectorAll("wfu_browser_tr");
    let nodeList = document.querySelectorAll(".wfu_row-1.wfu_browser-1");
    let elements = Array.from(nodeList);

    console.log(nodeList);
    console.log(elements);

    for(var index=0;index < getWFUOrderTable.length;index++){
        console.log("index" . getWFUOrderTable.length);
       console.log("xxx".getWFUOrderTable[index].innerHTML);
    }


}






    </script>


    </div>

    <div class="page-content">
        <?php the_content(); ?>
    </div>
</main>

<?php get_footer(); ?>


