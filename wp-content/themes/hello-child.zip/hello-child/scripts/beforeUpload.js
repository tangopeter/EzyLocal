
// function beforeUpload()
// {
// console.log("testytil")


// console.log("+++++++++++++++++++++++");

// var eztesty_var = testi;
//  console.log(eztesty_var);
// }