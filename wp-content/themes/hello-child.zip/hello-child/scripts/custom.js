
// console.log("+++++++++++++++++++++++");

// // function orderPage() {
//   const deliveryMethod = document.getElementById("userdata_1_field_7");
//   deliveryMethod.addEventListener('change', getDeliveryMethod);
//   const rural = document.getElementById("userdata_1_field_8");
//   rural.addEventListener('change', checkRuralDelivery);
//   const saturday = document.getElementById("userdata_1_field_9");
//   saturday.addEventListener('change', checkSatDelivery);
//   const toPostal = document.getElementById("userdata_1_field_10");
//   toPostal.addEventListener('click', toPostalClick)

//   const printQty = document.getElementById("userdata_1_field_16");
//   const eachPrice = document.getElementById("userdata_1_field_17");
//   const printPrice = document.getElementById("userdata_1_field_18");
//   const printTotal = document.getElementById("userdata_1_field_19");
//   const deliveryTotal = document.getElementById("userdata_1_field_20");
//   const orderTotal = document.getElementById("userdata_1_field_21");

//   let dm = currency(4.50).format();
//   let rp = currency(0.00).format();
//   let st = currency(0.00).format();
//   let total = currency(0.00).format();
//   let totalPrice = currency(0.00).format();

//   // Add a Delivery method Cost field
//   const delMethodPrice = document.createElement("p")
//   delMethodPrice.textContent = dm;
//   delMethodPrice.classList.add('delPriceMethod');
//   deliveryMethod.insertAdjacentElement('afterEnd', delMethodPrice);
//   // Add a Rural Delivery cost field
//   const ruralPrice = document.createElement("p")
//   ruralPrice.textContent = rp;
//   ruralPrice.classList.add('ruralPrice');
//   rural.insertAdjacentElement('afterEnd', ruralPrice);
//   // Add a Saturday Delivery cost field
//   const saturdayPrice = document.createElement("p")
//   saturdayPrice.textContent = st;
//   saturdayPrice.classList.add('satPrice');
//   saturday.insertAdjacentElement('afterEnd', saturdayPrice);

//   // Get the image settings
//   const size = document.getElementById("userdata_1_field_14");
//   const quanity = document.getElementById("userdata_1_field_16");
//   const price = document.getElementById("userdata_1_field_17");
//   size.addEventListener('change', getOrderSize);
//   quanity.addEventListener('change', getOrderSize);

//   window.onload = function exampleFunction() {
//     getOrderSize(event);
//   }
// // }
// // Get the delivery method and cost
// function getDeliveryMethod(event) {
//   // const result = document.querySelector('.delPriceMethod');
//   // var p = 0;
//   switch (event.target.value) {
//     case 'Post Env to 10x8 - $4.5':
//       dm = 4.50;
//       break;
//     case 'Courier local (Wellington) - $7':
//       dm = 7.00;
//       break;
//     case 'Courier North Island - $13':
//       dm = 13.00;
//       break;
//     case 'Courier South Island - $28':
//       dm = 28.00;
//       break;
//     case 'Courier Waiheke Island - $26':
//       dm = 26.00;
//       break;
//     case 'no charge by arrangement - $0':
//       dm = 0.00;
//       break;
//   }
//   delMethodPrice.textContent = currency(dm).format(); 
//   UpdateOrderTotals();
// };

// // Get the Rural delivery and cost
// function checkRuralDelivery() {
//   var checkBox = document.getElementById('userdata_1_field_8');
//   if (checkBox.checked == true) {
//     rp = 4.50;
//   } else {
//     rp = 0.00;
//   }
//   ruralPrice.textContent = currency(rp).format(); 
//   UpdateOrderTotals();
// }
// // Get the Saturday delivery and cost
// function checkSatDelivery() {
//   var checkBox = document.getElementById('userdata_1_field_9');
//   if (checkBox.checked == true) {
//     st = 5.00;
//   } else {
//     st = 0.00;
//   }
//   saturdayPrice.textContent = currency(st).format(); 
//   UpdateOrderTotals();
// }
// // Send to postal address
// function toPostalClick() {
//   console.log('-->  toPostal');
// }

// // Array for the prices
// var printPrices = new Array();

// var i0 =  ["dummy",0.00,0.50,1.00,1.50] ;
// var i1 = ["5x7_Lustre",1.20,0.95,0.80] ;
// var i2 = ["5x7.5_Lustre",1.20,0.95,0.80] ;
// var i3 = ["5x11_Lustre",3.00,3.00,3.00] ;
// var i4 = ["5x11_Laminated",3.00,3.00,3.00] ;
// var i5 = ["6x4_Lustre",0.25,0.25,0.25] ;
// var i6 = ["6x4.5_Lustre",0.30,0.30,0.30] ;
// var i7 = ["6x8_Lustre",2.80,2.50,2.00] ;
// var i8 = ["6x9_Lustre",2.80,2.50,2.00] ;
// var i9 = ["8x6_Supreme",3.00,3.00,3.00] ;
// var i10 = ["8x12_Supreme",5.50,5.50,5.50] ;
// var i11 = ["10x8_Gloss",5.90,5.00,4.50] ;
// var i12 = ["10x8_Lustre",5.90,5.00,4.50] ;
// var i13 = ["10x8_Laminated",8.90,7.00,4.20] ;
// var i14 = ["10x12_Gloss",10.50,9.00,7.50] ;
// var i15 = ["10x12_Lustre",10.50,9.00,7.50] ;
// var i16 = ["10x12.5_Gloss",11.90,9.50,9.50] ;
// var i17 = ["10x12.5_Lustre",11.90,9.50,9.50] ;
// var i18 = ["10x12.5_Laminated",12.40,10.00,10.00] ;
// var i19 = ["10x15_Gloss",14.50,12.00,10.75] ;
// var i20 = ["10x15_Lustre",14.50,12.00,10.75] ;
// var i21 = ["12x8_Lustre",6.00,5.50,4.50] ;
// var i21 = ["12x18_Lustre",21.00,21.00,21.00] ;
// var i22 =  ["6x20_Lustre",18.00,18.00,18.00] ;
// var i23 =  ["6x25_Lustre",22.00,22.00,22.00] ;
// var i24 =  ["10x20_Lustre",23.00,23.00,23.00] ;
// var i25 =  ["10x25_Lustre",26.00,26.00,26.00] ;
// var i26 =  ["12x20_Lustre",25.00,25.00,25.00] ;
// var i27 =  ["12x25_Lustre",30.00,30.00,30.00] ;

// printPrices.push(i0);
// printPrices.push(i1);
// printPrices.push(i2);
// printPrices.push(i3);
// printPrices.push(i4);
// printPrices.push(i5);
// printPrices.push(i6);
// printPrices.push(i7);
// printPrices.push(i8);
// printPrices.push(i9);
// printPrices.push(i10);
// printPrices.push(i11);
// printPrices.push(i12);
// printPrices.push(i13);
// printPrices.push(i14);
// printPrices.push(i15);
// printPrices.push(i16);
// printPrices.push(i17);
// printPrices.push(i18);
// printPrices.push(i19);
// printPrices.push(i20);
// printPrices.push(i21);
// printPrices.push(i22);
// printPrices.push(i23);
// printPrices.push(i24);
// printPrices.push(i25);
// printPrices.push(i26);
// printPrices.push(i27);

// /* *******************************
// Print order
// ********************************** */

// // Get the image size cost and Quanitity
// function getOrderSize(event) {
//   //get the size
//   const p = (event.target.value);
//   // get index of the size

//   // console.log("size: ",size.selectedIndex);
//   // console.log(printPrices[size.selectedIndex]);
//   const i = size.selectedIndex;
//   let pr = "0";
//   // get the quantity
//   const qty = printQty.value;
//    // console.log("qty = ", qty);

// // get the unit price
//  if (qty < 11) {
//     pr = printPrices[i][1];
//   } else if (qty > 10 && qty < 31) {
//     pr = printPrices[i][2];
//   } else if (qty > 30) {
//     pr = printPrices[i][3];
//   }
//   eachPrice.textContent = currency(pr).format();
//   // const price = document.getElementById("userdata_1_field_17");
//   eachPrice.value = currency(pr).format();

//   // get quantity x price & update the print price
//   var price = qty * pr;

//   printPrice.value = currency(price).format();
//   // console.log("printPrice = ", printPrice);


//   UpdateOrderTotals(event,price);
// };

// function UpdateOrderTotals(event, price) {
//   // console.log("printTotal = ", currency(price).format());
//   // get the print items total price
//   printTotal.value = currency(price).format();
//   //get the current delivery method & cost
//   const dm = delMethodPrice.textContent;
//   //get the current rural delivery cost
//   const rp = ruralPrice.textContent;
//   //get the current saturday delivery cost
//   const sd = saturdayPrice.textContent;
//   // Total it all
//   totalDelivery = currency(dm).add(rp).add(st);
//   deliveryTotal.value = currency(totalDelivery).format();

//   totalPrice = currency(total).add(price).add(totalDelivery);
//   // console.log("totalPrice = ", currency(totalPrice).format());
//   orderTotal.value = currency(totalPrice).format();
// }

// function testy(data) {
//   console.log("data: ")
//   // var eztesty = testi;
//    console.log(data);
// }
