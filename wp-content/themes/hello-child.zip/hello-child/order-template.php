<?php
/**
 * The template for displaying singular post-types: posts, pages and user-defined custom post types.
 *
 * @package HelloElementor
* Template Name: Order prints template
* Template Post Type: page
*/

?>
<?php acf_form_head(); ?>
<?php get_header(); ?>
<main id="content" <?php post_class( 'site-main' ); ?> role="main">
    <?php if ( apply_filters( 'hello_elementor_page_title', true ) ) : ?>
        <header class="page-header">
            <?php the_title( '<h1 class="entry-title">', '</h1>' ); ?>
        </header>
    <?php endif; ?>
    <div class="page-content">
        <?php the_content(); ?>
        <?php acf_form(); ?>
    </div>


</main>

<?php get_sidebar(); ?>
<?php get_footer(); ?>

